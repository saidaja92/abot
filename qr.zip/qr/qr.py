from newqr import NewQRLogin

newqr = NewQRLogin()

print("Headers: %s" % (", ".join(newqr.HEADERS)))
header = "ios_ipad"

token, cert = newqr.loginWithQrCode(header)

print("Access Token: " + token)
print("Certificate: " + cert)
