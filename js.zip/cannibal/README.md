
apt update
apt upgrade
pkg install coreutils  -y
apt install git -y
pkg install nodejs
pkg install nodejs-current-dev

git clone https://github.com/cannibalkiller/daffa

cd daffa
npm install
cd src
nano main.js

npm start

 follow in my chanel https://www.youtube.com/channel/UCW_i985LKCceZtOFouNbt3w



