<a href="https://www.img.live/image/azxklt"><img src="https://www.img.live/images/2020/01/05/1565537279814.jpg" alt="1565537279814.jpg" border="0" /></a>

## Running in Termux
```
pkg update
pkg upgrade
pkg install git
git clone https://github.com/teambotmax/JS-NEW
pkg install nodejs
pkg install coreutils
pkg install nodejs-current -y
pkg install nodejs-current-dev
cd JS-NEW
npm i
cd src
npm install
npm start

```
## Running in Vps
```
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install git
git clone https://github.com/teambotmax/JS-NEW
sudo apt-get install nodejs
sudo apt-get install coreutils
sudo apt-get install nodejs-current -y
sudo apt-get install nodejs-current-dev
cd JS-NEW
npm i
cd src
npm install
npm start

```
